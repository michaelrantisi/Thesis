import os
import cv2
from ultralytics import YOLO
import numpy as np

IMAGES_DIR = os.path.join('.', 'images')
base_image_path = os.path.join(IMAGES_DIR, r"C:\Users\USER\Desktop\thesis\code\MCD tests\test 1.jpg")
secondary_image_path = os.path.join(IMAGES_DIR, r"C:\Users\USER\Desktop\thesis\code\MCD tests\test1.2 change.png")
output_dir = r"C:\Users\USER\Desktop\thesis\code\tests\compare"
base_filename = os.path.basename(secondary_image_path)
new_filename = "{}_out.jpg".format(os.path.splitext(base_filename)[0])
secondary_image_path_out = os.path.join(output_dir, new_filename)

base_frame = cv2.imread(base_image_path)
secondary_frame = cv2.imread(secondary_image_path)

def preprocess_image(image):
    return image

base_frame = preprocess_image(base_frame)
secondary_frame = preprocess_image(secondary_frame)

model_path = r"C:\Users\USER\Desktop\thesis\code\runs\detect\train5\weights\best.pt"
model = YOLO(model_path)
threshold = 0.7

base_results = model(base_frame)[0]
secondary_results = model(secondary_frame)[0]

def apply_nms(results, threshold):
    boxes = []
    for result in results.boxes.data.tolist():
        x1, y1, x2, y2, score, class_id = result
        if score > threshold:
            boxes.append((int(x1), int(y1), int(x2), int(y2), score, int(class_id)))

    bboxes = np.array([box[:4] for box in boxes])
    scores = np.array([box[4] for box in boxes])
    indices = cv2.dnn.NMSBoxes(bboxes.tolist(), scores.tolist(), score_threshold=threshold, nms_threshold=0.4)

    if isinstance(indices, tuple):
        indices = indices[0]
    if len(indices) == 0:
        return []
    
    filtered_boxes = [boxes[i] for i in indices.flatten()]
    return filtered_boxes

base_components = apply_nms(base_results, threshold)
secondary_components = apply_nms(secondary_results, threshold)

print("Base components:", base_components)
print("Secondary components:", secondary_components)

def get_position_tolerance(bbox):
    width = bbox[2] - bbox[0]
    height = bbox[3] - bbox[1]
    return max(10, int(0.1 * min(width, height)))  

def is_within_tolerance(bc, sc, tolerance):
    return (abs(bc[0] - sc[0]) <= tolerance and
            abs(bc[1] - sc[1]) <= tolerance and
            abs(bc[2] - sc[2]) <= tolerance and
            abs(bc[3] - sc[3]) <= tolerance)

missing_components = []
for base_comp in base_components:
    base_x1, base_y1, base_x2, base_y2, base_score, base_class_id = base_comp
    found = False
    position_tolerance = get_position_tolerance(base_comp)
    for sec_comp in secondary_components:
        sec_x1, sec_y1, sec_x2, sec_y2, sec_score, sec_class_id = sec_comp
        if base_class_id == sec_class_id and is_within_tolerance(base_comp, sec_comp, position_tolerance):
            found = True
            break
    if not found:
        missing_components.append(base_comp)

print("Missing components:", missing_components)

H, W, _ = secondary_frame.shape
for comp in missing_components:
    x1, y1, x2, y2, score, class_id = comp

    x1, y1, x2, y2 = max(0, x1), max(0, y1), min(W, x2), min(H, y2)
    cv2.rectangle(secondary_frame, (x1, y1), (x2, y2), (0, 0, 255), 4) 
    cv2.putText(secondary_frame, f'Missing {base_results.names[int(class_id)].upper()}',
                (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 0, 255), 3, cv2.LINE_AA)

cv2.imwrite(secondary_image_path_out, secondary_frame)
cv2.destroyAllWindows()
