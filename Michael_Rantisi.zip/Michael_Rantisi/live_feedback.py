import cv2
from ultralytics import YOLO
import torch
import time
import pyttsx3

if not torch.cuda.is_available():
    raise Exception("CUDA is not available. Check your installation.")
print("Using GPU:", torch.cuda.get_device_name(0))

model_path = r"C:\Users\USER\Desktop\thesis\code\runs\detect\train5\weights\best.pt"
model = YOLO(model_path).to('cuda')

threshold = 0.5

cap = cv2.VideoCapture(0)

if not cap.isOpened():
    raise IOError("Cannot open webcam")

engine = pyttsx3.init()

object_counts = {}

feedback_interval = 10
last_feedback_time = time.time()

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame)[0]

    object_counts.clear()

    for result in results.boxes.data.tolist():
        x1, y1, x2, y2, score, class_id = result

        if score > threshold:
            class_name = results.names[int(class_id)].upper()
            if class_name in object_counts:
                object_counts[class_name] += 1
            else:
                object_counts[class_name] = 1
            
            cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 4)
            cv2.putText(frame, class_name, (int(x1), int(y1 - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)

    cv2.imshow('Frame', frame)

    current_time = time.time()
    if current_time - last_feedback_time >= feedback_interval:
        feedback_text = ', '.join([f"{count} {name}" for name, count in object_counts.items()])
        if feedback_text:
            engine.say(feedback_text)
            engine.runAndWait()
        last_feedback_time = current_time

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
