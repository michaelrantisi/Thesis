import cv2
from ultralytics import YOLO
hyp = {
    'lr0': 0.01,  
    'lrf': 0.2,   
    'momentum': 0.937,
    'weight_decay': 0.0005,
    'warmup_epochs': 3.0,
    'warmup_momentum': 0.8,
    'warmup_bias_lr': 0.1,
    'box': 0.05,
    'cls': 0.5,
    'cls_pw': 1.0,
    'obj': 1.0,
    'obj_pw': 1.0,
    'iou_t': 0.20,  
    'anchor_t': 4.0,
    'fl_gamma': 0.0,  
    'hsv_h': 0.015,  
    'hsv_s': 0.7,    
    'hsv_v': 0.4,    
    'degrees': 0.0,  
    'translate': 0.1,
    'scale': 0.5,
    'shear': 0.0
}


model = YOLO("yolov8n.yaml")
results = model.train(data="C:/Users/USER/Desktop/thesis/code/config.yaml", epochs=150)
